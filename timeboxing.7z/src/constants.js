export const INITIAL_COLUMNS_COUNT = 7;

export const MAX_COLUMNS_COUNT = 7;

export const MIN_COLUMNS_COUNT = 0;

export const WEEK_DAYS = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
